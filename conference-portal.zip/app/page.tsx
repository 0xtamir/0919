'use client'

import { useEffect, useMemo, useState } from 'react'
import { ArrowRight, CalendarDays, Check, Clock3, MapPin, Menu, Search, Users, X } from 'lucide-react'

type Speaker = { name: string; role: string; company: string; color: string; image: string; bio: string }
type Room = { email: string; room: string; status: 'Not Registered' | 'Registered' }

const speakers: Speaker[] = [
  { name: 'Б.Удвал', role: 'Хиймэл Оюун Эрхэлсэн Захирал', company: 'MCS Technologies', color: 'from-cyan-300 to-blue-600', image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/udval-HsZLhJAGlHrBXStVnmSSfzz3WBhpAy.jpg', bio: 'AI хэнийг түрүүлэх гээд ингэтлээ уралдаад байна вэ? Компаниуд, улс орнууд хаашаа ингэтлээ яарна вэ? “Томчууд” AI булаацалдаж байхад бид зүгээр хараад суух уу, эсвэл бидэнд ч бас ашиг “унах” уу? Энэ их өрсөлдөөний цаадах сонин хачин, боломж хоёрыг хамтдаа сонирхоцгооё' },
  { name: 'Х.Мөнхжаргал', role: 'Гүйцэтгэх Захирал', company: 'М Секьюритис', color: 'from-fuchsia-300 to-violet-600', image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Munkhjargal-RXnKRjOo9NEiMNSe1etSrAdJk3De9r.jpg', bio: '🪙📈 Алт, хөрөнгө оруулалт, эдийн засгийн сонин хачин... бас бидэнд хэрэгтэй, мэдчихвэл зүгээр зүйлс байгаа л гэнэ шүү 👀✨' },
  { name: 'Б.Мөнхсайхан', role: 'Founder', company: 'Buteyko Mongolia', color: 'from-amber-200 to-orange-600', image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/munkhsaikhan-8Y5jhSG4d4Z73FWedYi35lUjabQIL7.jpg', bio: '😮‍💨 Өдөрт 20,000+ удаа амьсгалдаг мөртлөө ихэнхдээ буруу амьсгалдаг гэнэ шүү. Харин зөв амьсгалж сурвал стресс багасна, нойр сайжирна, амьдрал хөнгөхөн болно... бүр зарим хүний хэлснээр шартах ч үгүй гэнэ! 😂🍺 Ингэхээр асуудал нь ажил, мөнгө, эдийн засаг биш байсан юм биш биз дээ... зүгээр л амьсгал буруу байсан юм болов уу? 🤔' },
]

const schedule = [
  ['09:00', 'Accounting Professional Proficiency Exam', 'Assigned exam rooms', 'All candidates'],
  ['12:00', 'Lunch break', 'Assembly Hall', ''],
  ['13:00', 'Хиймэл оюуны эргэн тойронд тэргүүлэгчдийн өрсөлдөөн', '', 'Б. Удвал'],
  ['13:30', 'Мөнгөө хаана хадгалах вэ?', '', 'Х. Мөнхжаргал'],
  ['14:00', 'Тэмцээн', '', ''],
  ['14:30', 'Зөв амьсгалахуй', '', 'Б. Мөнхсайхан'],
] as const

const initialRooms: Room[] = [
  { email: 'candidate1@example.com', room: 'Room 201', status: 'Not Registered' },
  { email: 'candidate2@example.com', room: 'Room 304', status: 'Not Registered' },
  { email: 'candidate3@example.com', room: 'Lab 02', status: 'Not Registered' },
  { email: 'candidate4@example.com', room: 'Room 108', status: 'Not Registered' },
  { email: 'candidate5@example.com', room: 'Room 305', status: 'Not Registered' },
]

function Countdown() {
  const [time, setTime] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 })
  useEffect(() => {
    const target = new Date('2026-09-19T09:00:00+08:00').getTime()
    const tick = () => { const diff = Math.max(0, target - Date.now()); setTime({ days: Math.floor(diff / 86400000), hours: Math.floor(diff / 3600000) % 24, minutes: Math.floor(diff / 60000) % 60, seconds: Math.floor(diff / 1000) % 60 }) }
    tick(); const id = window.setInterval(tick, 1000); return () => window.clearInterval(id)
  }, [])
  return <div className="countdown" aria-label="Countdown to the Accounting Professional Proficiency Exam">{Object.entries(time).map(([label, value]) => <div key={label}><strong>{String(value).padStart(2, '0')}</strong><span>{label}</span></div>)}</div>
}

export default function Page() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [selected, setSelected] = useState<Speaker | null>(null)
  const [query, setQuery] = useState('')
  const [rooms, setRooms] = useState(initialRooms)
  const filteredRooms = useMemo(() => rooms.filter((row) => row.email.toLowerCase().includes(query.toLowerCase())), [query, rooms])
  const nav = ['HOME', 'FIND MY ROOM', 'SCHEDULE', 'SPEAKERS', 'MCS HOLDING']

  return <main className="site-shell">
    <header className="nav-wrap"><a className="brand-logo" href="#top"><img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/R%26AD_white-P2ng0Fgtr8u707jTzHOpTX1WyGW4qm.png" alt="R&AD Accounting Professional Development" /></a><nav className={mobileOpen ? 'nav-links open' : 'nav-links'}>{nav.map((item) => <a key={item} href={item === 'HOME' ? '#top' : item === 'FIND MY ROOM' ? '#exam-rooms' : item === 'MCS HOLDING' ? '#speakers' : `#${item.toLowerCase()}`} onClick={() => setMobileOpen(false)}>{item}</a>)}</nav><button className="menu-button" aria-label={mobileOpen ? 'Close menu' : 'Open menu'} onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X /> : <Menu />}</button></header>

    <section className="hero" id="top"><div className="hero-grid" /><div className="orb orb-one" /><div className="orb orb-two" /><div className="hero-inner"><p className="eyebrow"><span className="live-dot" /> September 19, 2026 · 09:00 AM</p><h1>Accounting<br /><em>Professional</em><br />Proficiency Exam.</h1><p className="hero-copy">Your next professional milestone starts here. Check your assigned exam room, review the schedule, and arrive ready.</p><div className="hero-actions"><a className="button primary" href="#exam-rooms">Find my exam room <ArrowRight data-icon="inline-end" /></a><a className="button ghost" href="#schedule">View schedule</a></div><div className="hero-meta"><div><CalendarDays /><b>September 19</b><small>2026 · 09:00 AM</small></div><div><MapPin /><b>Selbe School</b><small>Ulaanbaatar, Mongolia</small></div><div><Clock3 /><b>Be prepared</b><small>Arrive early</small></div></div></div><div className="hero-side"><span>SCROLL TO EXPLORE</span><div /></div></section>

    <section className="countdown-section"><div><p className="eyebrow">The examination begins in</p><h2>Make your preparation count.</h2></div><Countdown /></section>

    <section className="rooms section-pad" id="exam-rooms"><div className="section-kicker">01 / Your examination room</div><div className="rooms-heading"><div><h2>Find your<br /><span>exam room.</span></h2><p>Search using your email address to view your assigned room and register your attendance.</p></div><label className="search-field"><Search /><input aria-label="Search by email" type="email" placeholder="Search by email address" value={query} onChange={(e) => setQuery(e.target.value)} /></label></div><div className="room-table"><div className="room-head"><span>Email</span><span>Room</span><span>Status</span></div>{filteredRooms.map((row) => <div className="room-row" key={row.email}><span className="candidate email-cell">{row.email}</span><span>{row.room}</span><span className={`status ${row.status === 'Registered' ? 'confirmed' : 'pending'}`}>{row.status === 'Registered' && <Check />} {row.status === 'Not Registered' && <button className="register-room" onClick={() => setRooms((current) => current.map((item) => item.email === row.email ? { ...item, status: 'Registered' } : item))}>Register</button>}{row.status === 'Registered' && row.status}</span></div>)}</div>{filteredRooms.length === 0 && <p className="no-results">No assignment found for this email address.</p>}</section>

    <section className="schedule section-pad" id="schedule"><div className="section-heading"><div><div className="section-kicker">02 / Schedule</div><h2>One day.<br /><span>One opportunity.</span></h2></div></div><div className="timeline">{schedule.map(([time, title, room, person], index) => <div className="timeline-row" key={time}><time>{time}</time><div className="time-line"><i className={index === 0 ? 'bright' : ''} /></div><div className="session"><h3>{title}</h3>{room && <p><MapPin /> {room}{person && <><span>·</span><Users /> {person}</>}</p>}</div><ArrowRight className="session-arrow" /></div>)}</div></section>

    <section className="speakers section-pad" id="speakers"><div className="section-kicker">03 / The people</div><div className="section-heading"><h2>Meet the<br /><span>experts.</span></h2><p>Our examination and professional development team is here to support your next step.</p></div><div className="speaker-grid">{speakers.map((speaker, index) => <button className="speaker-card" key={speaker.name} onClick={() => setSelected(speaker)}><div className={`speaker-art bg-gradient-to-br ${speaker.color}`}><span>0{index + 1}</span><img className="speaker-photo" src={speaker.image} alt={`${speaker.name} speaker portrait`} /></div><div className="speaker-info"><h3>{speaker.name}</h3><p>{speaker.role} <span>·</span> {speaker.company}</p></div></button>)}</div></section>

    <footer><div className="footer-top"><a className="brand-logo" href="#top"><img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/R%26AD_white-P2ng0Fgtr8u707jTzHOpTX1WyGW4qm.png" alt="R&AD Accounting Professional Development" /></a><p>Accounting Professional<br />Proficiency Exam · 2026</p><div className="footer-links"><a href="#schedule">Schedule</a><a href="#speakers">Speakers</a><a href="#exam-rooms">Find my room</a></div></div><div className="footer-bottom"><span>© 2026 R&AD. All rights reserved.</span><span>Professional excellence starts here.</span></div></footer>

    {selected && <div className="dialog-backdrop" role="presentation" onClick={() => setSelected(null)}><div className="speaker-dialog" role="dialog" aria-modal="true" aria-label={selected.name} onClick={(e) => e.stopPropagation()}><button className="dialog-close" onClick={() => setSelected(null)} aria-label="Close speaker details"><X /></button><div className={`dialog-art bg-gradient-to-br ${selected.color}`}><img className="speaker-photo" src={selected.image} alt={`${selected.name} speaker portrait`} /></div><div className="dialog-content"><h2>{selected.name}</h2><p className="dialog-role">{selected.role} · {selected.company}</p><p>{selected.bio}</p></div></div></div>}
  </main>
}
